package com.mycompany.tap_u1_tarea2;

import javax.swing.JOptionPane;

public class CalculatorTDA {
    
    private int decimal;
    private int moudulo;
    private String numeroBase;
    private int count;
    boolean error;
    
    public CalculatorTDA(String decimal){
        this.moudulo = 0;  
        this.error(decimal);
    }
    
    public String ConvertirBinario(){
        if(this.decimal < 0 || this.error == true){
            this.numeroBase = "Error, introdusca solo números enteros y mayores o iguales a 0";
            return this.numeroBase;
        }
        
        this.numeroBase = "";
        while(decimal > 0){
            this.moudulo = this.decimal % 2;
            this.numeroBase = this.moudulo + this.numeroBase;
            this.decimal = decimal / 2;
        }
        
        if(this.count == 0){
            return this.numeroBase = "0";
        }
        
        return this.numeroBase;
    }
    
    public String ConvertirOctal(){
        if(this.decimal < 0 || this.error == true){
            this.numeroBase = "Error, introdusca solo números enteros y mayores o iguales a 0";
            return this.numeroBase;
        }
        
        this.numeroBase = "";
        while(decimal > 0){
            this.moudulo = this.decimal % 8;
            this.numeroBase = this.moudulo + this.numeroBase;
            this.decimal = decimal / 8;
        }
        
        if(this.count == 0){
            return this.numeroBase = "0";
        }
        
        return this.numeroBase;
    }
    
    public String ConvertirHrexadecimal(){
        if(this.decimal < 0 || this.error == true){
            this.numeroBase = "Error, introdusca solo números enteros y mayores o iguales a 0";
            return this.numeroBase;
        }
        
        this.numeroBase = "";
        while(decimal > 0){
            this.moudulo = this.decimal % 16;
            
            if(this.moudulo > 9){
                switch (this.moudulo) {
                    case 10:
                        this.numeroBase = "A" + this.numeroBase;
                        break;
                    case 11:
                        this.numeroBase = "B" + this.numeroBase;
                        break;
                    case 12:
                        this.numeroBase = "C" + this.numeroBase;
                        break;
                    case 13:
                        this.numeroBase = "D" + this.numeroBase;
                        break;
                    case 14:
                        this.numeroBase = "E" + this.numeroBase;
                        break;
                    case 15:
                        this.numeroBase = "F" + this.numeroBase;
                        break;
                    default:
                        break;
                }
            }else{
                this.numeroBase = this.moudulo + this.numeroBase;
            }
            
            this.decimal = decimal / 16;
        }
        
        if(this.count == 0){
            return this.numeroBase = "0";
        }
        
        return this.numeroBase;
    }
    
    private void error(String decimal){
        try{
            this.count = Integer.parseInt(decimal);
            this.decimal = Integer.parseInt(decimal);
        }catch(Exception e){
            this.numeroBase = "Error, introdusca solo números enteros y mayores o iguales a 0";
            this.error = true;
        }
    } 
    
    public void setNumeroBase(String numeroBase){
        this.numeroBase = numeroBase;
    }
}
